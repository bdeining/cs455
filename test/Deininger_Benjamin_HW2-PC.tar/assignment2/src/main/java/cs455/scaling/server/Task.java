package cs455.scaling.server;

public interface Task {

    void execute();

}
