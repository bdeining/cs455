package cs455.scaling.util;

import java.text.SimpleDateFormat;

public class Constants {

    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("HH:mm:ss");

    public static final int BUFFER_SIZE = 8192;

}
